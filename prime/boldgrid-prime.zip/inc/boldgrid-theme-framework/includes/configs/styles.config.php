<?php
/**
 * Configurations related to sass/css files.
 *
 * @package Boldgrid_Theme_Framework
 *
 * @since 1.5
 */

return array(
	'versions' => array(
		'font-awesome' => '4.7',
		'boldgrid-components' => '2.0.0',
	),
);
